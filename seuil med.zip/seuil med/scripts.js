document.getElementById('seuilForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const national = parseFloat(document.getElementById('national').value);
    const regional = parseFloat(document.getElementById('regional').value);

    if (isNaN(national) || isNaN(regional)) {
        alert("Veuillez entrer des notes valides.");
        return;
    }

    const seuil = (national * 0.75) + (regional * 0.25);

    document.getElementById('result').innerText = `Le seuil de médecine est : ${seuil.toFixed(2)}`;
});
